# Text written by the assistant: changes to the MCP server

Most of what people read in Atlas is assembled from the assistant's fields: finding titles, the reason a suggestion is made, review themes. Today the server's instructions say nothing about voice or length for these fields, and the limits are much higher than the house style allows (README-DS §9). As a result, generated text comes out about three times longer than the text Atlas writes itself.

## 1. Field limits (in each tool's description, and enforced in the validator)

| Tool | Field | Today | New | What it is |
|---|---|---|---|---|
| add_finding | `title` | one sentence, ≤140 characters | ≤ 8 words, ≤ 60 characters, result first | What changes or what you saw |
| add_finding | `why` | ≤ 400 | ≤ 110 characters, one sentence, one number | The strongest evidence |
| add_finding | `details` (new) | — | ≤ 400, optional | The cause and the rest of the numbers, shown on demand |
| propose_page_screenshots, propose_product_page, propose_page_test, propose_release_action, suggest_fields, propose_prices and every tool with a `why` / `reason` | `why` / `reason` | ≤ 300 or no limit | ≤ 110 characters, one sentence; the rest goes in `details` | The "why" line on the card |
| all propose_ tools | `confidence` (new, optional) | — | 1–3 | Shown as Not very sure · Fairly sure · Sure |
| all tools with text in another language | `gloss` (new, optional) | — | ≤ 110 characters | "Means: …" under the text |

The App Store's own field limits (≤ 30 name, ≤ 170 promotional text, and so on) stay as they are. They are Apple's rules, not house style.

When a field is too long, refuse it as today, with the reason, so the assistant rewrites it: "why is 164 characters; at most 110. Move the rest to details."

## 2. Paragraph to add to `server-instructions.txt` (after the second sentence)

> Everything you write for the person (titles, why, details, review themes, notes) is shown on a card in Atlas, so write it the way Atlas writes: short, plain, second person, result first. Titles: what changes, at most 8 words ("Lifetime: $79.99 → $59.99"). Why: the strongest evidence, one sentence, one number, at most 110 characters ("9 of your last 220 reviews call it too expensive."). Everything else goes in details. Don't describe yourself or how you worked ("I analysed…", "Claude found…"); say what you found. Words: suggestion, push, Review & Push. Never: simply, just, easily, seamlessly, powerful, leverage, magic, please, successfully, "!". Round numbers people read; exact ones in details.

## 3. What the person sees should say "suggestion"

The tool names (`propose_…`, `list_proposals`) stay as they are, so no client breaks. But every text the person sees must say "suggestion". Of the 79 texts the person sees that said "proposed", "proposal" or "propose", `copy-rewrite.csv` changes 69. The other 10 are placeholder names (`{proposalCount}`) or texts written for the assistant (they name MCP actions); leave those.

## 4. Apple's errors

Store Page, Analytics and Pricing have 121 places that show `error.localizedDescription` raw. Route them through one function, like `AppleErrorCopy` in the design-system handoff:
- the template says what happened and what to do;
- Apple's text goes into Details.

`copy-rewrite.csv` gives a suggested template in the `suggest` column for the rows that have one.

## 5. Interface names quoted in the assistant's texts

Some tool descriptions and replies name buttons or labels that `copy-rewrite.csv` renames. Update them so that the assistant and the interface say the same thing:

- `Proposed by {client}` → `Suggested by {client}`: `WithdrawReleaseActionTool.swift:69`, `ProposePageTestTool+Withdraw.swift:55`
- "Recommended" prices → "Suggested" prices, where it means Pricing's mode: `GetPricesTool.swift:23`, `ListAppsTool.swift:14`
- "Product Pages" as the section name → "Custom Product Pages"; check `PageShotsMCPRun.swift:24`, `ProposeProductPageTool.swift:108` and `ProposeProductPageTextsTool.swift:92`

Tool names (`propose_…`) stay as they are.
