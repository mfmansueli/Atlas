Apply the copy rewrite in `copy-rewrite.csv` and `mcp-copy-changes.md` (both at the repo root, from the design side). Work on a branch `copy-rewrite`.

1. Each row of `copy-rewrite.csv` is one place in the code; the same text in another place may be left as is on purpose (for example "Recommended" stays outside Pricing). Rows where `old` equals `new` only ask for the code change in `suggest`. Each row has `file` (path:line), `key`, `old` and `new`.
   - Replace `old` with `new` at that place, in the same literal or `String(localized:)` call.
   - Placeholders are written `{name}` in the CSV. Keep the Swift interpolation that is in the code (`\(name)`).
   - If `old` isn't at that line anymore, find it in the same file. If it's not there, list the row as skipped. Don't guess.
2. Fragments joined at runtime (`notes` says "fragment"): after replacing, read the whole assembled sentence and make sure it still reads well. List any that don't.
3. Rows with a `suggest` value ask for a code change, for example wrapping `error.localizedDescription` in a template. Do these as a separate commit.
4. Renamed buttons and menu items: search the Help articles, tooltips and the MCP texts for the old name, and update them to match.
5. Do what `mcp-copy-changes.md` says:
   - field limits in the tool descriptions and the validator;
   - the paragraph for `server-instructions.txt`;
   - the Apple error function.
   Don't rename any MCP tool.
6. Move the 547 hard-coded strings marked `should_be_in_catalog = YES` in `copy-inventory.csv` into `String(localized:)`. Create `Localizable.xcstrings` with a `kind:<kind>` comment on each entry, as `CLAUDE-design-rule.md` asks.
7. Build, and run the tests and the snapshot tests.

When done, reply with:
- the rows applied and the rows skipped (with the reason);
- the fragments that read badly;
- the buttons renamed and where their old names were updated;
- whether the build and the tests pass.
