# Design consistency (rule zero) — paste into the repo's CLAUDE.md

Design consistency is a development rule in Atlas, not a finishing step. Every screen speaks the same language so the app stays easy to navigate.

## Where the design lives

1. **Source:** canvas *Atlas* → page *Design system* → **README-DS** (rule zero, colour, section icons, type, buttons, badges, shape, AI motion v2), board **64** (every token drawn) and board **68** (motion v2 playing).
2. **In code:** `design-tokens.json` and the `DesignSystem` package (`Tokens.swift`, `Motion.swift`, components, `DesignCatalogView.swift`).
3. **In the app:** debug builds → **Debug → Design System Catalog… (⌥⌘D)**. Check here before and after building or refining a screen.

## Rules for every change

- No raw values in views: no hex colours, font sizes, radii, paddings, durations or springs. Use tokens (`Color.ai`, `.atlasTextStyle(.headline)`, `Radius.card`, `Space.l`, `Motion.base`). If a value is missing, add the token to README-DS, `design-tokens.json` and the module first.
- Colour meaning: **blue** = what you do (one filled blue per card or sheet; repeated actions are tinted); **purple** = what AI brought (never a filled action button; filled only when the assistant waits for you); green/amber/red describe state; AI failures are amber; non-AI loading is a grey skeleton.
- Type: only the ten `AtlasTextStyle`s. Nothing under 10 pt.
- Buttons: only the seven kinds in README-DS §4. Starting AI from inside a page = secondary + sparkles + purple label.
- Motion: only the five AI effects of Motion v2 (`trail`, `working`, `arrived`, `decided`, `needsYou`) through the `DesignSystem` modifiers. At most one loop on screen; no one-shot over 1.2 s; nothing animates on opening a screen; progress only from countable units, never from time; every effect reads Reduce Motion.
- Done means: tokens only; checked in light, dark, Increase Contrast and Reduce Motion, in the screen and in the catalog.
- Changing the system: README-DS and boards first, then tokens and module, then screens.

When a screen in the prototype disagrees with README-DS, build README-DS.

# Voice and content (rule zero for words) — README-DS §9 and §10

Every word must make the next decision faster. Short, clear, and enough to decide with full confidence.

- **One source:** README-DS §9 (voice, three layers, risk levels, templates, words) and §10 (hierarchy). In code: `design-tokens.json → copy` and `Copy.swift`.
- **Every string has a kind.** In the String Catalog, each comment starts with `kind:<kind>` (button, toast, error, banner…). `scripts/copy-lint.py` checks the limits and banned words; it runs in CI and fails the build.
- **Three layers per decision:** title (≤ 8 words, result first) · why (≤ 110 characters, one number) · details on demand. Optional gloss (“Means: …”) and how-sure (Not very sure · Fairly sure · Sure).
- **Safety by risk level, once per screen:** 0 nothing · 1 toast with Undo · 2 one line in Review & Push · 3 confirmation sheet (what, who, when, how to undo) · 4 confirm in place naming what goes.
- **Apple's errors are never shown raw.** Use `AppleErrorCopy` (401, 403, 404, 409, 429, 5xx, offline, expired key, partial). The code and raw message go in Details.
- **Text from the assistant (MCP)** arrives as `AssistantSuggestion` fields. Call `problems()`; if not empty, refuse with the reasons so the assistant rewrites. Never render free text from MCP.
- **Words:** suggestion, push, Review & Push, Autopilot, assistant, capture, set, template. Apple's own terms stay where App Store Connect uses them. Never: simply, just, easily, seamlessly, powerful, leverage, AI-powered, magic, please, oops, successfully, “!”.
- **Hierarchy:** section top = summary line → first card → safety line. Order by impact (blocks App Review → revenue → reach → polish). One banner per screen; at most 6 cards before “Show N More”; group repeats (“12 countries: lower price”). Card order: title · why · (gloss) · actions · details.
- **Done means:** the string passes the lint, fits at 860 × 560 and in German (+30%), and has a VoiceOver label of name, state, count.
- **Snapshot check:** add each screen's empty, loading, error and done states to the snapshot tests, so copy changes are reviewed as images.

## Sidebar footer (approved 24 Nov · README-DS §11, board 71)

- Two fixed rows at every height: **Settings** and **Help ▾** side by side with their names, then the Version card. Never icon-only.
- Help ▾ is a menu: Atlas Help (⌘?), Show the Tour, Keyboard Shortcuts (also in macOS's Help menu).
- Under 600 pt of sidebar height: hide the app card's "other apps" line and tighten rows to 27 pt. Sections never disappear; if they ever don't fit, the list scrolls under the footer with a 14 pt fade.

## Icons: Apple SF Symbols only (approved 24 Nov · README-DS §13, board 72, icons-sf-symbols.csv)

- Every interface icon is an SF Symbol: `Image(systemName:)` or `Label(_:systemImage:)`. No custom glyphs, no text characters as icons (✓ ! ↯ ▶ ▼), no SVG.
- No tiles or gradients behind icons. Section icons are tinted with their system color (`SectionStyle`): Store Page blue, Screenshots orange, Custom Product Pages teal, In-App Events pink, Nominations brown, Pricing green, Reviews yellow, Analytics indigo, Overview and App Information gray.
- Status uses `StatusSymbol` (checkmark.circle.fill green, exclamationmark.triangle.fill orange, exclamationmark.circle.fill red, info.circle.fill gray, wifi.slash). Every banner starts with one.
- Menus and context menus show a symbol column (macOS 26) for items with a standard symbol; selection menus keep only the checkmark. Destructive items: trash in red.
- Empty states: one large symbol in tertiary label above the title (`ContentUnavailableView`).
- Purple only for what the assistant brought (sparkles). Push buttons in sheets stay text only.
- Not icons, keep as they are: the person's app icon, Atlas's app icon and menu-bar mark, third-party logos, artwork, charts.

## Pricing: product page and prices by country (approved 24 Nov · updated 25 Nov · README-Redesign, board 73)

The product page replaces the old price screen: **remove "Edit Prices…" and its table**. Everything it had lives here, ordered by impact: what changes money is in the table, why a price is suggested opens on the price, the rest waits in filters, menus and views.

- **Page.** Each product in Pricing opens its own page: breadcrumb "Pricing › <product>" (⌘[ back), ⌃ ⌄ at the right of the breadcrumb for the previous and next product (⌥⌘↑ / ⌥⌘↓) without going back to the list. Tabs: Prices by Country · Results · Offers · Review Screenshot · Details.
- **Banner (the screen's one banner).** "Suggested prices in 104 countries." with the Built-in source chip and how-sure ("Not very sure") on the title line; the why below, plus the baseline "Based on purchasing power alone: Atlas doesn't read Sales and Trends yet." Actions: the strategy pop-up, Dismiss All, Accept All N….
- **Strategy** (app-wide) is a pop-up in the banner: Show Suggestions · Apply Recommended Prices (adds them to Review & Push; you still push) · Keep Prices (no price suggestions). Customize Suggestions… opens an `.inspector`: method (price index), base country and price, price index (World Bank PPP price level), fallback chain (IMF implied PPP rate → region median → Apple's automatic price, always last), limits (never below 30% of the base, never above Apple's automatic price, round to the nearest price point), how sure. "Use Built-in" resets.
- **Table** (`Table` + `TableColumnCustomization`). Always: country and region · price (pop-up button) · change. On by default: In US$ ("≈ $46"), **Proceeds** (from the price point's proceeds; money, so visible) and How it's set. Columns menu adds Feels Like ("$83 2.1×": the price for local incomes in US$ against the US), Equalized (Apple's equalized price), Currency, Source (World Bank / IMF / Region median, with a Fallback pill) and Reason. Sort (`KeyPathComparator`) by country, US$, feels like, change. Multi-select `Set<Territory.ID>` with a bottom bar: Accept N Suggested · Set N to Automatic · Deselect.
- **Change column.** A suggestion in purple (→ R$ 129,90) with a change pill (`PriceChange`): decrease gray ▼ −48%, increase amber ▲ +17%. Accept / Dismiss per country. After a change: "was R$ 249,90", the pill, Undo. How it's set: Base price · Automatic · Set by you · Accepted suggestion · Adjusted suggestion, plus "Not pushed"; "—" = unchanged.
- **Find and filter.** `.searchable` by name, ISO code, currency or region; segments All · Suggested · Set by You · Automatic with counts; a Filters button with a count: region (Americas, Europe, Asia Pacific, Middle East and Africa) and Changed Only, Increases Only, Fallback Only. When filtered, one line says what ("Europe · Increases only · 2 of 40 shown") with Clear Filters.
- **Price popover** (click the price or the suggestion), three radio choices: **Suggested price** with a −/+ `Stepper` over the territory's price points, the change pill, "At R$ 129,90 it feels like $43 for local incomes, 1.1× the US price; you get ≈ $20.", "Why: R$ 249,90 feels like 2.1× the US price there.", "World Bank PPP price level · factor 0.56 · Not very sure" ("Adjusted from …" when stepped); **Apple's automatic price** (today's value, ≈ US$); **A price you choose** (price points with ≈ US$, Suggested and Now marked). Base-price row: price points only. Button: Accept / Set <price> / Use Automatic Price. Every change waits in Review & Push, one row per product; toast with Undo.
- **Views.** Segmented Table · Map · Histogram (filters apply to all). Map: a tile grid of countries coloured by `PriceLevel` (feels-like ratio, Now / Suggested), aiFill ring where a suggestion waits, code and ratio as text, legend; click opens the price popover. Histogram: Swift Charts `BarMark`, countries per $5 of price in US$, now (systemGray) and suggested (aiFill), dashed line at the US base price.
- **Footer.** "175 countries and regions · N likely held back by price · N not pushed" and "Price changes start: Right Away ▾ / On a Date…".
- **Accept All N…** opens a sheet (risk level 3): N go down / N go up with three examples each; when price changes start (right away / a date → the price's `startDate`); where a price goes up, "Keep their current price" for existing subscribers (on by default → `preserveCurrentPrice`); when off, an amber note that some countries ask subscribers to agree to an increase or the subscription ends at renewal. Primary: Add to Review & Push.
- **Results tab.** How earlier price changes did, 28 days before vs 28 after: 3 cards (subscription starts, proceeds, countries with enough people), then per country: price before → after, starts, page view → start, proceeds, Better · Worse · About the same · Too few to tell (Analytics' words). Worse rows: Restore… (old price into Review & Push). Nothing to compare: `ContentUnavailableView`.
- **Other tabs.** Offers (intro, promotional, win-back, offer codes; none for one-time purchases). Review Screenshot (status + Review Screenshot…). Details (type, product ID, group, base price, availability, Apple's commission, tax category, Family Sharing).
- **"Preview in"** replaces "What people pay": one country pop-up with search, countries with a change first, ‹ › to the next one; each product shows the new price, the old one struck through, ≈ US$; clicking a product opens its page on that country.
- **Small windows.** Table < 780 pt: In US$, Proceeds and How it's set fold under the country ("Automatic · ≈ $46 · you get ≈ $39"); optional columns hide. At 860 × 560: product name and base price move into the breadcrumb row, the banner keeps one line, filter counts hide, Filters and Columns become icons, the inspector floats over the table, the popover scrolls.

## On the App Store preview (approved 24 Nov · README-Redesign)

- The App Preview comes first (poster frame, play button, length), then every screenshot, in one horizontally scrolling row.
- An In-App Event card ("Happening now", badge, name, short description on its artwork, dates) appears under the screenshots only while an event is live; it opens In-App Events.
