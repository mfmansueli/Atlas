# atlas-design-system · handoff (23 Nov 2026 · updated 25 Nov)

The starting point for Atlas's single source of design truth in the app's repo.

| File | What it is |
|---|---|
| `design-tokens.json` | Every design decision as data: colour (light, dark, high contrast), section icons, type, buttons, shape, badges, pills, motion tokens, the five AI effects and their rules, and copy (limits per kind, risk levels, glossary, banned words, Apple errors, MCP schema, hierarchy). Same values as README-DS. |
| `Sources/DesignSystem/Tokens.swift` | Colour, type, radius, spacing and section styles as Swift; `PriceLevel` (map scale) and `PriceChange` (change pill) for Pricing. |
| `Sources/DesignSystem/Motion.swift` | Motion v2: tokens and the AI effects as view modifiers (progress in units, spark landing, arrived, image develops, needs-you nudge). |
| `Sources/DesignSystem/DesignCatalogView.swift` | The Design System Catalog window for debug builds (⌥⌘D). |
| `Sources/DesignSystem/Copy.swift` | Copy kinds and limits, `Copy.check`, `AssistantSuggestion` (MCP fields with `problems()`), `AppleErrorCopy`. |
| `scripts/copy-lint.py` | Lints every String Catalog entry against `design-tokens.json → copy`; exits 1 on problems (CI). |
| `CLAUDE-design-rule.md` | Rule zero, to paste into the repo's `CLAUDE.md`, plus the approved screens (sidebar footer, icons, Pricing product page, App Store preview). |
| `icons-sf-symbols.csv` | Every interface icon and its SF Symbol. |

Order of work for Claude Code: add the package and the asset catalogue Color Sets → add the catalog window → move existing screens to tokens one section at a time → replace old AI effects with Motion v2 → add `kind:` comments to the String Catalog and turn on `copy-lint.py` → route MCP text through `AssistantSuggestion` and Apple errors through `AppleErrorCopy` → rewrite strings from the spreadsheet *Textos do Atlas*.

Written from memory and to check on macOS 26: SF Symbol names, `PhaseAnimator`, `TextRenderer`, `.symbolEffect(.drawOn)`, Liquid Glass button styles, control heights.

**25 Nov:** Pricing's product page replaces the old price screen (Edit Prices…): see CLAUDE-design-rule.md → Pricing, and `color.priceLevel`, `color.priceChart`, `pill.change` in design-tokens.json.
