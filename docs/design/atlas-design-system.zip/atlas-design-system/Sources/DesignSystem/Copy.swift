import Foundation

// Atlas copy system — README-DS §9 and §10, same values as design-tokens.json → "copy".
// Every user-visible string has a kind. The kind sets its limit.

public enum CopyKind: String, CaseIterable, Codable {
    case sectionDescription = "section-description", sectionSummary = "section-summary"
    case fieldLabel = "field-label", hint, placeholder, button, menuItem = "menu-item"
    case tooltip, accessibilityLabel = "accessibility-label", pill, badge, banner, toast, error
    case emptyTitle = "empty-title", emptyBody = "empty-body", loading, doneState = "done-state"
    case sheetTitle = "sheet-title", sheetBody = "sheet-body", progressStep = "progress-step"
    case notificationTitle = "notification-title", notificationBody = "notification-body"
    case historyEntry = "history-entry", helpStep = "help-step"
    case suggestionTitle = "suggestion-title", suggestionWhy = "suggestion-why"

    /// Word limit (nil = no word limit).
    public var maxWords: Int? {
        switch self {
        case .sectionDescription: 12
        case .sectionSummary, .suggestionTitle: 8
        case .fieldLabel: 3
        case .hint: 8
        case .placeholder, .loading, .doneState, .progressStep, .emptyTitle, .notificationTitle: 6
        case .button, .menuItem: 4
        case .tooltip, .historyEntry: 10
        case .pill, .badge: 2
        case .banner, .notificationBody: 14
        case .toast: 12
        case .error: 20
        case .emptyBody: 18
        case .sheetBody: 25
        case .helpStep: 15
        case .sheetTitle, .accessibilityLabel, .suggestionWhy: nil
        }
    }

    /// Character limit (nil = none).
    public var maxCharacters: Int? { self == .suggestionWhy ? 110 : nil }
}

public enum Copy {
    public static let banned = ["simply", "just", "easily", "seamlessly", "powerful", "leverage",
                                "ai-powered", "magic", "please", "oops", "successfully"]
    public static let replaced: [String: String] = [
        "proposal": "suggestion", "recommendation": "suggestion", "upload": "push",
        "sync": "push", "publish": "push", "loading…": "say what is loading",
    ]
    public static let howSure = [1: "Not very sure", 2: "Fairly sure", 3: "Sure"]
    public static let glossPrefix = "Means: "

    public struct Issue: Equatable, CustomStringConvertible {
        public let kind: CopyKind, text: String, reason: String
        public var description: String { "[\(kind.rawValue)] “\(text)”: \(reason)" }
    }

    /// Words, ignoring ICU placeholders like {count} and separators like “·”.
    public static func wordCount(_ s: String) -> Int {
        s.replacingOccurrences(of: #"\{[^}]*\}"#, with: "X", options: .regularExpression)
         .split(whereSeparator: { $0.isWhitespace })
         .filter { !["·", "—", "→", "|"].contains(String($0)) }.count
    }

    public static func check(_ text: String, as kind: CopyKind) -> [Issue] {
        var out: [Issue] = []
        let n = wordCount(text)
        if let m = kind.maxWords, n > m { out.append(.init(kind: kind, text: text, reason: "\(n) words, limit \(m)")) }
        if let c = kind.maxCharacters, text.count > c { out.append(.init(kind: kind, text: text, reason: "\(text.count) characters, limit \(c)")) }
        if text.contains("!") { out.append(.init(kind: kind, text: text, reason: "no exclamation marks")) }
        let lower = text.lowercased()
        for w in banned where lower.range(of: #"\b\#(w)\b"#, options: .regularExpression) != nil {
            out.append(.init(kind: kind, text: text, reason: "banned word “\(w)”"))
        }
        for (w, r) in replaced where lower.range(of: #"\b\#(NSRegularExpression.escapedPattern(for: w))"#, options: .regularExpression) != nil {
            out.append(.init(kind: kind, text: text, reason: "“\(w)” → \(r)"))
        }
        if kind == .button || kind == .menuItem, let f = text.first, f.isLowercase {
            out.append(.init(kind: kind, text: text, reason: "title case, verb first"))
        }
        return out
    }
}

// MARK: - Text written by the assistant (MCP)

/// What the assistant sends through MCP for one suggestion. Atlas renders the layers itself.
public struct AssistantSuggestion: Codable, Equatable {
    public struct Evidence: Codable, Equatable {
        public enum Source: String, Codable { case reviews, analytics, asc, web }
        public let source: Source, text: String, n: Int?
    }
    public let title: String          // ≤ 8 words, result first
    public let why: String            // ≤ 110 characters, one sentence, one number
    public let details: String?       // on demand
    public let evidence: [Evidence]
    public let gloss: String?         // only when content is not in the interface language
    public let confidence: Int        // 1…3 → howSure

    /// Empty = accepted. Otherwise the reasons go back to the assistant so it rewrites.
    public func problems() -> [String] {
        var p = Copy.check(title, as: .suggestionTitle).map(\.reason).map { "title: " + $0 }
        p += Copy.check(why, as: .suggestionWhy).map(\.reason).map { "why: " + $0 }
        if why.filter({ $0 == "." }).count > 1 { p.append("why: one sentence") }
        if !(1...3).contains(confidence) { p.append("confidence: 1, 2 or 3") }
        if evidence.isEmpty { p.append("evidence: at least one item") }
        return p
    }
}

// MARK: - Apple's errors, never shown raw

public enum AppleErrorCopy {
    public static func message(status: Int?, offline: Bool = false, action: String = "do this",
                               thing: String = "This", retryAfter: Int = 30) -> String {
        if offline { return String(localized: "You’re offline. Changes wait in Review & Push.", comment: "kind:error") }
        switch status ?? 0 {
        case 401: return String(localized: "Apple didn’t accept this key. Check it in Settings → Keys.", comment: "kind:error")
        case 403: return String(localized: "This key can’t \(action). Use an Admin or App Manager key.", comment: "kind:error")
        case 404: return String(localized: "\(thing) isn’t in App Store Connect anymore. Refresh to update.", comment: "kind:error")
        case 409: return String(localized: "App Store Connect changed this since you opened it. Refresh, then try again.", comment: "kind:error")
        case 429: return String(localized: "Apple asked Atlas to slow down. Trying again in \(retryAfter) s.", comment: "kind:error")
        case 500...599: return String(localized: "Apple didn’t answer. Try again in a minute.", comment: "kind:error")
        default: return String(localized: "Something didn’t go through. Try again, or see Details.", comment: "kind:error")
        }
    }
}
