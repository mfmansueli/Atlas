// Atlas · DesignSystem · Motion v2 (“the spark”, approved 23 Nov 2026)
// Five AI effects, each a view modifier that reads Reduce Motion itself. Board 68 on the canvas plays them.
// API names written from memory: check .phaseAnimator, .keyframeAnimator, TextRenderer and .symbolEffect on macOS 26.

import SwiftUI

public enum Motion {
    public static let fast   = Animation.easeOut(duration: 0.15)
    public static let base   = Animation.timingCurve(0.2, 0.7, 0.2, 1, duration: 0.25)
    public static let slow   = Animation.timingCurve(0.2, 0.7, 0.2, 1, duration: 0.4)
    public static let step   = Animation.timingCurve(0.65, 0, 0.35, 1, duration: 0.5)   // one progress unit
    public static let layout = Animation.spring(response: 0.35, dampingFraction: 0.8)
    public static let tick   = Animation.spring(response: 0.45, dampingFraction: 0.6)
    public static let legDuration: Double = 0.7                                          // one leg of the trail
    public static let sweepPeriod: Double = 2.8                                          // the only loop
    public static func stagger(_ index: Int) -> Double { Double(min(index, 5)) * 0.07 }    // at most 6 animated
}

// MARK: 2 · Working — progress only in countable units, in steps, with a sweep between steps

public struct AIProgress: Equatable {
    public var done: Int
    public var total: Int?          // nil: nothing to count → no bar, only the step name
    public var step: String         // “Capturing Annual”, “Reading the project”
    public var secondsLeft: Int?    // only after a few units, from the real average

    public var label: String {
        guard let total else { return step }
        if total <= 20 { return "\(step) · \(done) of \(total)" }
        return "\(step) · \(Int((Double(done) / Double(total) * 100).rounded(.down)))% · \(done) of \(total)"
    }
}

public struct AIProgressBar: View {
    let progress: AIProgress
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    public init(_ progress: AIProgress) { self.progress = progress }

    public var body: some View {
        if let total = progress.total, total > 0 {
            GeometryReader { geo in
                let w = geo.size.width * CGFloat(progress.done) / CGFloat(total)
                ZStack(alignment: .leading) {
                    Capsule().fill(.quaternary)
                    Capsule().fill(LinearGradient(colors: [.aiFill, .aiFill.opacity(0.75)], startPoint: .leading, endPoint: .trailing))
                        .frame(width: w)
                        .overlay { if !reduceMotion { Sweep().clipShape(Capsule()) } }
                        .animation(reduceMotion ? nil : Motion.step, value: progress.done)
                }
            }
            .frame(height: 3)
            .accessibilityElement()
            .accessibilityLabel(progress.label)
        }
    }

    private struct Sweep: View {
        var body: some View {
            // A soft highlight crosses the filled part, then pauses: “still working”, without faking progress.
            PhaseAnimator([0.0, 1.0, 1.0]) { phase in
                GeometryReader { g in
                    LinearGradient(colors: [.clear, .white.opacity(0.42), .clear], startPoint: .leading, endPoint: .trailing)
                        .frame(width: g.size.width * 0.9)
                        .offset(x: -g.size.width + phase * g.size.width * 2.2)
                }
            } animation: { phase in phase == 1 ? .timingCurve(0.45, 0, 0.55, 1, duration: Motion.sweepPeriod * 0.62) : .linear(duration: Motion.sweepPeriod * 0.38) }
        }
    }
}

// MARK: 1 · Trail — the spark goes from where you asked to Autopilot, then to the place of the work

public struct Spark: View {
    public init() {}
    public var body: some View {
        Image(systemName: "sparkle").foregroundStyle(Color.aiFill).shadow(color: .aiFill.opacity(0.55), radius: 4)
    }
}

/// Put on the view where the work happens; `signing` true plays the one bloom when the result arrives.
public struct SparkLanding: ViewModifier {
    let isWorking: Bool
    let signing: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    public func body(content: Content) -> some View {
        content.overlay(alignment: .topTrailing) {
            if isWorking || signing {
                Spark()
                    .scaleEffect(signing && !reduceMotion ? 1.5 : 1)
                    .opacity(signing ? 0 : 1)
                    .animation(reduceMotion ? nil : Motion.slow, value: signing)
                    .offset(x: 6, y: -6)
            }
        }
    }
}
// The travel itself is an overlay at window level: animate a Spark along button → Autopilot → place,
// Motion.legDuration per leg on Motion.base. With Reduce Motion, skip the travel.

// MARK: 3 · Arrived — tint, then text word by word or image developing

public struct AIArrived: ViewModifier {
    let index: Int
    @State private var shown = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    public func body(content: Content) -> some View {
        content
            .opacity(shown ? 1 : 0)
            .offset(y: shown || reduceMotion ? 0 : 4)
            .onAppear {
                withAnimation(reduceMotion ? .easeOut(duration: 0.2) : Motion.slow.delay(Motion.stagger(index))) { shown = true }
            }
    }
}

public struct AIImageDevelops: ViewModifier {
    @State private var developed = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    public func body(content: Content) -> some View {
        content
            .blur(radius: developed || reduceMotion ? 0 : 9)
            .saturation(developed || reduceMotion ? 1 : 0.2)
            .scaleEffect(developed || reduceMotion ? 1 : 0.97)
            .onAppear { withAnimation(reduceMotion ? .easeOut(duration: 0.2) : .timingCurve(0.2, 0.7, 0.2, 1, duration: 0.8)) { developed = true } }
    }
}
// Text word by word: a TextRenderer that reveals each run 0.28 s, 35 ms apart, from 2 pt blur and 2 pt lower, plus a caret.

// MARK: 5 · Needs you — one nudge, then still

public struct NeedsYouNudge: ViewModifier {
    let trigger: Bool
    @State private var nudged = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    public func body(content: Content) -> some View {
        content
            .scaleEffect(nudged ? 1.06 : 1)
            .onChange(of: trigger) { _, now in
                guard now, !reduceMotion else { return }
                withAnimation(Motion.tick) { nudged = true }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { withAnimation(Motion.tick) { nudged = false } }
            }
    }
}

public extension View {
    func sparkLanding(working: Bool, signing: Bool = false) -> some View { modifier(SparkLanding(isWorking: working, signing: signing)) }
    func aiArrived(index: Int = 0) -> some View { modifier(AIArrived(index: index)) }
    func aiImageDevelops() -> some View { modifier(AIImageDevelops()) }
    func needsYouNudge(_ trigger: Bool) -> some View { modifier(NeedsYouNudge(trigger: trigger)) }
}

// 4 · Accepted / Dismissed / Undone: use Motion.base for the tint (ai → neutral), Motion.layout for the card closing,
// and a check drawn with .symbolEffect(.drawOn) if available. The accepted item stays in place, “Not pushed”.
