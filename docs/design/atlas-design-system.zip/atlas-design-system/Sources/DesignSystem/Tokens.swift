// Atlas · DesignSystem · Tokens
// The one place for colour, type, shape and spacing. Values mirror design-tokens.json and README-DS.
// Rule zero: views never use raw colours, sizes, radii, paddings, durations or springs. Add a token first.
// Colours live in the asset catalogue as Color Sets with Any, Dark (and High Contrast where listed).

import SwiftUI

public extension Color {
    static let atlasLabel      = Color("label", bundle: .module)        // or .primary
    static let atlasLabel2     = Color("label2", bundle: .module)       // or .secondary
    static let atlasLabel3     = Color("label3", bundle: .module)       // placeholders, disabled, separators only
    static let accentAtlas     = Color("AccentColor", bundle: .module)
    static let accentText      = Color("accentText", bundle: .module)
    static let ai              = Color("ai", bundle: .module)
    static let aiFill          = Color("aiFill", bundle: .module)
    static let onAiFill        = Color("onAiFill", bundle: .module)
    static let aiSurface       = Color("aiSurface", bundle: .module)
    static let aiEdge          = Color("aiEdge", bundle: .module)
    static let ok              = Color("ok", bundle: .module)
    static let warn            = Color("warn", bundle: .module)
    static let warnTint        = Color("warnTint", bundle: .module)
    static let okTint          = Color("okTint", bundle: .module)       // done surface (README-DS §1, Nov 25)
    static let okEdge          = Color("okEdge", bundle: .module)
    static let accentTint      = Color("accentTint", bundle: .module)   // numbered steps: accentTint fill, accentText digit
    static let err             = Color("err", bundle: .module)
}

public enum AtlasTextStyle: CaseIterable {
    case display, largeTitle, title1, title2, title3, headline, body, callout, subheadline, footnote

    public var font: Font {
        switch self {
        case .display:     return .system(size: 32, weight: .bold)
        case .largeTitle:  return .largeTitle.bold()
        case .title1:      return .title.weight(.semibold)
        case .title2:      return .title2.weight(.semibold)
        case .title3:      return .title3.weight(.semibold)
        case .headline:    return .body.weight(.semibold)
        case .body:        return .body
        case .callout:     return .callout
        case .subheadline: return .subheadline
        case .footnote:    return .footnote
        }
    }
    /// −1.5% tracking for titles of 17 pt and up.
    var tracking: CGFloat { [.display, .largeTitle, .title1, .title2].contains(self) ? -0.015 : 0 }
}

public extension View {
    func atlasTextStyle(_ style: AtlasTextStyle) -> some View { font(style.font).tracking(style.tracking * 17) }
}

public enum Radius { public static let tag: CGFloat = 4, menuRow: CGFloat = 6, field: CGFloat = 8, banner: CGFloat = 10, card: CGFloat = 12, popover: CGFloat = 16, sheet: CGFloat = 20 }
public enum Space  { public static let xs: CGFloat = 4, s: CGFloat = 8, m: CGFloat = 12, l: CGFloat = 16, xl: CGFloat = 20, xxl: CGFloat = 24, xxxl: CGFloat = 32
                     public static let page: CGFloat = 20, card: CGFloat = 16 }

/// Section icons (approved 24 Nov · README-DS §13, board 72): an SF Symbol tinted with an Apple system color.
/// No tile, no gradient. System colors adapt to dark mode and Increase Contrast by themselves.
public struct SectionStyle {
    public let tint: Color, symbol: String
    public static let overview     = SectionStyle(tint: Color(nsColor: .systemGray),   symbol: "square.grid.2x2")
    public static let storePage    = SectionStyle(tint: Color(nsColor: .systemBlue),   symbol: "doc.text")
    public static let screenshots  = SectionStyle(tint: Color(nsColor: .systemOrange), symbol: "iphone")
    public static let productPages = SectionStyle(tint: Color(nsColor: .systemTeal),   symbol: "rectangle.stack")
    public static let inAppEvents  = SectionStyle(tint: Color(nsColor: .systemPink),   symbol: "calendar")
    public static let nominations  = SectionStyle(tint: Color(nsColor: .systemBrown),  symbol: "rosette")
    public static let appInfo      = SectionStyle(tint: Color(nsColor: .systemGray),   symbol: "info.circle")
    public static let pricing      = SectionStyle(tint: Color(nsColor: .systemGreen),  symbol: "tag")
    public static let reviews      = SectionStyle(tint: Color(nsColor: .systemYellow), symbol: "star")
    public static let analytics    = SectionStyle(tint: Color(nsColor: .systemIndigo), symbol: "chart.bar")
}

/// Status symbols: always these SF Symbols, never a custom glyph or a text character.
public enum StatusSymbol {
    public static let done = ("checkmark.circle.fill", Color(nsColor: .systemGreen))
    public static let needsYou = ("exclamationmark.triangle.fill", Color(nsColor: .systemOrange))
    public static let error = ("exclamationmark.circle.fill", Color(nsColor: .systemRed))
    public static let info = ("info.circle.fill", Color(nsColor: .systemGray))
    public static let offline = ("wifi.slash", Color(nsColor: .secondaryLabelColor))
}

/// Pricing map and histogram (README-Redesign, board 73). Colour sets "priceLevel0"…"priceLevel4" with Any and Dark
/// from design-tokens.json → color.priceLevel; each tile also shows its code and ratio as text.
public enum PriceLevel: Int, CaseIterable {
    case muchCheaper, cheaper, aboutTheSame, pricier, muchPricier
    /// Feels-like ratio = (local price ÷ exchange rate ÷ (1 + tax)) ÷ purchasing-power factor ÷ US base price.
    public init(ratio: Double) {
        switch ratio { case ..<0.7: self = .muchCheaper; case ..<0.9: self = .cheaper; case ..<1.15: self = .aboutTheSame; case ..<1.6: self = .pricier; default: self = .muchPricier }
    }
    public var fill: Color { Color("priceLevel\(rawValue)", bundle: .module) }
    public var label: Color { Color("priceLevelLabel\(rawValue)", bundle: .module) }
    public var legend: String { ["< 0.7×", "0.7–0.9×", "0.9–1.15×", "1.15–1.6×", "≥ 1.6×"][rawValue] }
    public static let histogramNow = Color(nsColor: .systemGray)
    public static let histogramSuggested = Color.aiFill
}

/// The change pill in Pricing: increases amber (they can cost subscribers), decreases neutral.
public struct PriceChange {
    public let percent: Int
    public var isIncrease: Bool { percent > 0 }
    public var symbol: String { isIncrease ? "arrowtriangle.up.fill" : "arrowtriangle.down.fill" }
    public var text: String { (percent > 0 ? "+" : "−") + "\(abs(percent))%" }
    public var tint: Color { isIncrease ? .warn : .atlasLabel2 }
    public var background: Color { isIncrease ? .warnTint : Color(nsColor: .quaternaryLabelColor) }
    public init(from old: Double, to new: Double) { percent = Int((((new / old) - 1) * 100).rounded()) }
}

extension Color {
    // Hex colors: only for fixed artwork. Interface icons use system colors (SectionStyle, StatusSymbol).
    init(hex: UInt32) { self.init(red: Double((hex >> 16) & 0xFF) / 255, green: Double((hex >> 8) & 0xFF) / 255, blue: Double(hex & 0xFF) / 255) }
}
