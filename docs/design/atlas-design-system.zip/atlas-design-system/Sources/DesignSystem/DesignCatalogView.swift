// Atlas · DesignSystem · Design System Catalog
// Debug builds: Debug → Design System Catalog… (⌥⌘D). Drawn by this module, so it is always the truth.
// The first place to look when building or refining a screen. Check light, dark, Increase Contrast and Reduce Motion here.

import SwiftUI

public struct DesignCatalogView: View {
    @State private var page: Page? = .colour
    enum Page: String, CaseIterable, Identifiable { case colour = "Colour", type = "Type", buttons = "Buttons", badges = "Badges & pills", sections = "Section icons", motion = "AI motion"; var id: String { rawValue } }

    public init() {}

    public var body: some View {
        NavigationSplitView {
            List(Page.allCases, selection: $page) { Text($0.rawValue).tag($0) }
        } detail: {
            ScrollView {
                VStack(alignment: .leading, spacing: Space.xxl) {
                    switch page ?? .colour {
                    case .colour:   colours
                    case .type:     types
                    case .buttons:  buttons
                    case .badges:   Text("Badge, Pill and SourceChip from this module, in every kind.").atlasTextStyle(.callout)
                    case .sections: sections
                    case .motion:   motion
                    }
                }
                .padding(Space.page)
            }
        }
        .frame(minWidth: 900, minHeight: 640)
    }

    private var colours: some View {
        let list: [(String, Color, String)] = [("label", .atlasLabel, "Text"), ("label2", .atlasLabel2, "Secondary text"), ("label3", .atlasLabel3, "Never readable text"),
            ("accent", .accentAtlas, "Do it"), ("accentText", .accentText, "Links"), ("ai", .ai, "AI text"), ("aiFill", .aiFill, "AI counts, spark, progress"),
            ("aiSurface", .aiSurface, "Suggestion cards"), ("ok", .ok, "Live, passes"), ("warn", .warn, "Needs an answer, AI failures"), ("err", .err, "Errors")]
        return VStack(alignment: .leading, spacing: Space.s) {
            ForEach(list, id: \.0) { item in
                HStack(spacing: Space.m) {
                    RoundedRectangle(cornerRadius: Radius.field).fill(item.1).frame(width: 44, height: 28)
                    Text(item.0).font(.body.monospaced()); Text(item.2).atlasTextStyle(.callout).foregroundStyle(Color.atlasLabel2)
                }
            }
        }
    }

    private var types: some View {
        VStack(alignment: .leading, spacing: Space.s) {
            ForEach(AtlasTextStyle.allCases, id: \.self) { s in Text(String(describing: s)).atlasTextStyle(s) }
        }
    }

    private var buttons: some View {
        VStack(alignment: .leading, spacing: Space.m) {
            Button("Submit for Review…") {}.buttonStyle(.borderedProminent).controlSize(.large)
            Button("Choose Folder…") {}.buttonStyle(.bordered).controlSize(.large)
            Button("Accept") {}.buttonStyle(.bordered).tint(.accentAtlas)
            Button { } label: { Label("Make Review Screenshots…", systemImage: "sparkles") }.buttonStyle(.bordered).foregroundStyle(Color.ai)
            Button("Delete…", role: .destructive) {}.buttonStyle(.bordered)
            Text("One filled blue per card or sheet. Purple fill only when the assistant waits for you.").atlasTextStyle(.callout).foregroundStyle(Color.atlasLabel2)
        }
    }

    private var sections: some View {
        let all: [(String, SectionStyle)] = [("Overview", .overview), ("Store Page", .storePage), ("Screenshots", .screenshots), ("Custom Product Pages", .productPages), ("In-App Events", .inAppEvents), ("Nominations", .nominations), ("App Information", .appInfo), ("Pricing", .pricing), ("Reviews", .reviews), ("Analytics", .analytics)]
        return VStack(alignment: .leading, spacing: Space.s) {
            ForEach(all, id: \.0) { s in
                HStack {
                    Label { Text(s.0) } icon: { Image(systemName: s.1.symbol).foregroundStyle(s.1.tint) }
                }
            }
        }
    }

    @State private var units = 1
    private var motion: some View {
        VStack(alignment: .leading, spacing: Space.l) {
            Text("Working · progress in units").atlasTextStyle(.headline)
            AIProgressBar(AIProgress(done: units, total: 3, step: "Capturing")).frame(width: 320)
            Button("Next unit") { units = units % 3 + 1 }.buttonStyle(.bordered)
            Text("Arrived").atlasTextStyle(.headline)
            Text("Deine Woche auf einer ruhigen Seite").padding(Space.m).background(Color.aiSurface, in: RoundedRectangle(cornerRadius: Radius.banner)).aiArrived()
            Text("Every effect here reads Reduce Motion. Turn it on in System Settings → Accessibility → Display and look again.").atlasTextStyle(.callout).foregroundStyle(Color.atlasLabel2)
        }
    }
}

// In the app: add a Debug menu command in debug builds only.
// #if DEBUG
// CommandMenu("Debug") { Button("Design System Catalog…") { openWindow(id: "design-catalog") }.keyboardShortcut("d", modifiers: [.option, .command]) }
// Window("Design System Catalog", id: "design-catalog") { DesignCatalogView() }
// #endif
