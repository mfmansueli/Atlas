#!/usr/bin/env python3
"""Atlas copy lint. Checks every English string in the String Catalogs against design-tokens.json → copy.
Each entry's comment must start with `kind:<kind>` (README-DS §9). Usage: python3 scripts/copy-lint.py [repo-root]
Exit 1 when a string breaks a rule, so it can run in CI and as a pre-commit hook."""
import json, re, sys, pathlib
root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '.')
tok = json.load(open(next(root.rglob('design-tokens.json'))))['copy']
kinds, banned = tok['kinds'], [b for b in tok['banned'] if b != '!']
alias = {'empty-title': ('empty-state', 'titleMaxWords'), 'empty-body': ('empty-state', 'bodyMaxWords'),
         'notification-title': ('notification', 'titleMaxWords'), 'notification-body': ('notification', 'bodyMaxWords'),
         'help-step': ('help-article', 'stepMaxWords'), 'suggestion-title': (None, 8)}
def words(s): return len([w for w in re.sub(r'\{[^}]*\}|%[@dlf]|%\d\$[@dlf]', 'X', s).split() if w not in '·—→|'])
problems, missing, n = [], [], 0
for cat in root.rglob('*.xcstrings'):
    if '.build' in cat.parts: continue
    for key, e in json.load(open(cat)).get('strings', {}).items():
        loc = e.get('localizations', {}).get('en', {}).get('stringUnit', {})
        text = loc.get('value', key); n += 1
        m = re.match(r'kind:([a-z-]+)', e.get('comment', ''))
        if not m: missing.append(f'{cat.name}: “{key}”'); continue
        k = m.group(1); lim = None
        if k in alias:
            base, f = alias[k]; lim = f if base is None else kinds.get(base, {}).get(f)
        elif k in kinds: lim = kinds[k].get('maxWords')
        elif k != 'suggestion-why': problems.append(f'unknown kind {k}: “{text}”'); continue
        if lim and words(text) > lim: problems.append(f'[{k}] {words(text)}/{lim} words: “{text}”')
        if k == 'suggestion-why' and len(text) > 110: problems.append(f'[{k}] {len(text)}/110 chars: “{text}”')
        if '!' in text: problems.append(f'[{k}] exclamation: “{text}”')
        for b in banned:
            if re.search(rf'\b{re.escape(b)}\b', text, re.I): problems.append(f'[{k}] banned “{b}”: “{text}”')
        if k in ('button', 'menu-item') and text[:1].islower(): problems.append(f'[{k}] title case: “{text}”')
        if k == 'loading' and text.strip().lower().startswith('loading'): problems.append(f'[{k}] say what is loading: “{text}”')
print(f'{n} strings · {len(problems)} problems · {len(missing)} without kind')
for p in problems: print('  ' + p)
for p in missing[:40]: print('  no kind: ' + p)
sys.exit(1 if problems or missing else 0)
