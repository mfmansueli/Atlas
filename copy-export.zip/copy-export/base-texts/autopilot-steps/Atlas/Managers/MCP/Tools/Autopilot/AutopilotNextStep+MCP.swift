//
//  AutopilotNextStep+MCP.swift
//  Atlas
//

import Foundation

extension AutopilotNextStep {
    /// `next_step`'s result: what to do, and with which tools.
    func mcpJSON(run: AutopilotRun?) -> JSONValue {
        switch self {
        case .noRun, .done:
            closingJSON(run: run)
        case .capture, .chooseScreens, .record:
            capturingJSON(run: run)
        case let .wait(reason, seconds):
            ["action": "wait", "reason": .string(reason), "retryAfterSeconds": .int(seconds)]
        case .recordAgain, .design:
            beforeChoosingJSON(run: run)
        case .revise, .revisePreview, .animateHeader, .reviseLoop:
            revisionJSON(run: run)
        case let .writeCaptions(overflows):
            Self.writeCaptionsJSON(overflows)
        case let .writeArtworkTexts(needs):
            Self.writeArtworkTextsJSON(needs)
        case let .designVariant(request):
            Self.designVariantJSON(request, run: run)
        case let .suggestScreens(request):
            Self.suggestScreensJSON(request, run: run)
        }
    }

    /// Before anything's designed: the screens, their captures, and the
    /// App Preview's recordings.
    private func capturingJSON(run: AutopilotRun?) -> JSONValue {
        switch self {
        case let .capture(targets, retries): Self.captureJSON(targets: targets, retries: retries, run: run)
        case .chooseScreens: Self.chooseScreensJSON
        case let .record(targets): Self.recordJSON(targets: targets)
        default: ["action": "none"]
        }
    }

    /// The chosen header's loop: animate it, or change it for the
    /// person's note.
    private func headerLoopJSON(run: AutopilotRun?) -> JSONValue {
        guard let run else { return ["action": "none"] }
        switch self {
        case let .animateHeader(conceptID): return Self.animateHeaderJSON(conceptID: conceptID, run: run)
        case let .reviseLoop(note): return Self.reviseLoopJSON(note: note, run: run)
        default: return ["action": "none"]
        }
    }

    /// Recording moments again, then designing: the steps before the
    /// person chooses a direction.
    private func beforeChoosingJSON(run: AutopilotRun?) -> JSONValue {
        switch self {
        case let .recordAgain(screenIDs):
            [
                "action": "record_again",
                "moments": .array(screenIDs.map { .string($0) }),
                "how": """
                These App Preview moments are to be recorded again before the design step: the person asked, or almost \
                nothing moves in them. For each, call rerecord_moment with moment_id to see where and why, record only \
                that screen with something happening on camera, upload it and call rerecord_moment again with the \
                upload ID. The rest of the recording stays.
                """,
            ]
        case let .design(remaining):
            if let run, run.usesConcepts {
                [
                    "action": "design",
                    "remaining": .int(remaining),
                    "how": .string(Self.directionsHow(run: run)),
                    "concepts": Self.conceptsJSON(run: run),
                ]
            } else {
                [
                    "action": "design",
                    "remaining": .int(remaining),
                    "how": .string(Self.designHow(plan: run?.plan, ownDesign: run?.designsFromTheApp == true)),
                ]
            }
        default:
            ["action": "none"]
        }
    }

    /// How to design the directions: the screenshots as a template and the
    /// header and search as pages; without screenshots, only what the run
    /// makes.
    static func designHow(plan: AutopilotPlan?, ownDesign: Bool = false) -> String {
        let source = ownDesign ? AutopilotRun.ownDesignHow : "design with the person's design project"
        let lead = "Call get_design_brief, \(source), and send each direction with propose_direction: "
        let pages = """
        \(plan?.alsoMakes.artworkSize.mcpPlaces ?? "the header and search") as your own HTML pages (try them with \
        render_artwork first) that show what the person asked, its askedByThePerson, first
        """
        let end = " They arrive one by one; the person chooses one."
        guard let plan, !plan.makesScreenshots else {
            return lead + "the screenshots as an Atlas template (template and/or ops on a base starter) and, when the brief has artworkDesign, "
                + pages + "." + end
        }
        guard plan.alsoMakes.makesArtwork else {
            let look = "this run makes no screenshots, so the template (template and/or ops on a base starter) is the App Preview's captions and end card."
            return lead + look + end
        }
        let preview = plan.previewDisplays.isEmpty
            ? "No screenshot template: leave base, template and ops out."
            : "No screenshot template: base, template and ops only style the App Preview's captions and end card."
        return lead + "this run makes no screenshots (the live set stays), so only " + pages + ", in artworkDesign. " + preview + end
    }

    /// After the rehearsal every language reaches its screens the same way,
    /// and Atlas checks each capture's text itself: Bruma's run took
    /// a minute a capture looking at each one, over 5 hours for 324.
    static let batchCaptureHow = """
    The rehearsal passed, so the other languages reach their screens the same way. Capture a device's screens for \
    a language in one go: the UI test with the locale's testArguments (its screenshots exported with xcrun \
    xcresulttool), or one script that launches each with its arguments, waits as long as the rehearsal needed and \
    screenshots it. Where commands run one at a time and no script can (Atlas's own Claude Code), send the \
    calls that don't wait on each other together: upload and report one capture while the next screen launches. \
    Look only at the captures whose file size stands out or that report_capture's check flags: Atlas \
    reads every capture's text, language, cut-offs, prompts and blank space itself.
    """

    /// `revise_direction` and `revise_app_preview`: the person's changes.
    private func revisionJSON(run: AutopilotRun?) -> JSONValue {
        switch self {
        case let .revisePreview(note, review):
            Self.revisePreviewJSON(note: note, review: review, run: run)
        case .animateHeader, .reviseLoop:
            headerLoopJSON(run: run)
        case let .revise(note):
            if let run, run.usesConcepts, !(run.revision?.askedConcepts ?? []).isEmpty {
                Self.reviseConceptsJSON(note: note, run: run)
            } else {
                Self.reviseDirectionJSON(note: note, run: run)
            }
        default:
            ["action": "none"]
        }
    }

    /// `none` and `done`: nothing to do now, and why.
    private func closingJSON(run: AutopilotRun?) -> JSONValue {
        if case .noRun = self {
            return [
                "action": "none",
                "say": "No Autopilot run is waiting. Ask the person to open Atlas → Screenshots → Run Autopilot… and press Start Autopilot.",
            ]
        }
        return ["action": "done", "say": .string(Self.doneSay(run: run))]
    }

    /// At the plan, done means the suggested screens are in; after it, the
    /// person approves the set in Autopilot (Approve All), which only puts
    /// it in Review & Push with every other change: Autopilot never pushes.
    static func doneSay(run: AutopilotRun?) -> String {
        if run?.stage == .plan {
            return "Your suggestions are in Atlas's plan; the person adds the ones they want. Nothing else to do now."
        }
        if run?.guidedReview?.isFinished == true {
            return """
            The person approved the new set: it waits in Atlas's Review & Push with their other changes. Nothing is \
            uploaded until the person pushes from there.
            """
        }
        return """
        The new set is made. The person reviews it in Atlas's Autopilot and approves it, which puts it in Review & \
        Push with their other changes. Nothing is uploaded until the person pushes from there.
        """
    }

    /// MB Admin's run: the person pressed Retry without the change, and
    /// Claude Code stopped with the run stuck on it.
    static let projectChangeRetryNote = """
    The fix is a change to the project. Read the file it names: when the change is there, capture the screen again. \
    When it isn't, call report_capture_problem for this screen again with the same fix (the person then changes the \
    project, keeps the capture they have or uploads one) and go on; don't stop on it.
    """

    private static func captureJSON(targets: [AutopilotCaptureTarget], retries: [AutopilotProblem], run: AutopilotRun?) -> JSONValue {
        let items: [JSONValue] = targets.prefix(40).map { target in
            var item: [String: JSONValue] = [
                "screen": .string(target.screenID),
                "name": .string(run?.plan.screen(id: target.screenID)?.name ?? target.screenID),
                "displayType": .string(target.displayType.mcpValue),
                "locale": .string(target.locale),
            ]
            // iPhone Duo's closed screens are captured on its cover display,
            // its open ones on the inner display.
            if let pose = run?.plan.duoPose(for: target) { item["pose"] = .string(pose.rawValue) }
            return .object(item)
        }
        let fixes: [JSONValue] = retries.map { problem in
            var item: [String: JSONValue] = [
                "screen": .string(problem.target.screenID),
                "displayType": .string(problem.target.displayType.mcpValue),
                "locale": .string(problem.target.locale),
                "fix": .string(problem.proposedFix ?? ""),
            ]
            if problem.wasRefused, let command = problem.refusedCommand {
                item["refused"] = .string(command)
                item["note"] = .string(
                    "This command was refused. The person may have changed the project since (see fix): read it again, and don't run the refused command."
                )
            } else if problem.needsProjectChange {
                item["note"] = .string(Self.projectChangeRetryNote)
            }
            return .object(item)
        }
        var json: [String: JSONValue] = [
            "action": "capture",
            "remaining": .int(run?.remainingTargets.count ?? targets.count),
            "targets": .array(items),
            "retryWithFix": .array(fixes),
            "how": """
            Capture each target up to 3 times, upload each PNG to the plan's upload URL and call report_capture \
            with the upload ID, attempt and a score from 0 to 1 (content filled in, no keyboard, alert or \
            spinner, nothing private, matches the caption) with notes saying why. Look at the PNG of each \
            screen's first capture on each device before reporting it: an empty state, a "select an item" \
            placeholder, a blank or black screen or an almost empty list is no store screenshot, so set the state \
            up (sample data, select the first item) and capture it again. When a screen can't be \
            reached, call report_capture_problem and go on with the others. When the fix is a change to the \
            project, report it once with changesProject: true: Atlas holds that screen on that device in \
            the other languages. When this Mac can't run a device at all because its runtime isn't installed, report it \
            once with affectsDevice: true; a simulator that's only missing Atlas makes itself (next_step waits \
            meanwhile), so don't report that. \
            Don't stop while next_step says capture: report what you can't capture, then ask next_step again, \
            and it gives you the rest.
            """,
        ]
        if let run, !run.remainingRecordings.isEmpty {
            json["record"] = .array(run.remainingRecordings.map(Self.recordingJSON))
            json["recordHow"] = .string(AutopilotRun.recordingHow)
        }
        if let run, let rehearsal = run.plan.rehearsalLocale {
            let rehearsing = targets.contains(where: run.plan.isRehearsal)
            json["phase"] = .string(rehearsing ? "rehearsal" : "capture")
            if rehearsing {
                json["rehearsal"] = .string("""
                Each screen on each device is captured in \(run.plan.primaryLocale) and \(rehearsal) before its other \
                languages, which come once it's done: check that it reaches its screen in \(rehearsal) too, in that \
                language, with nothing cut off. A screen or device that can't go on holds back only its own languages.
                """)
            } else {
                json["pace"] = .string(Self.batchCaptureHow)
            }
        }
        return .object(json)
    }

    private static func writeCaptionsJSON(_ overflows: [AutopilotOverflow]) -> JSONValue {
        let items: [JSONValue] = overflows.map { item in
            var json: [String: JSONValue] = [
                "locale": .string(item.locale),
                "slot": .int(item.slot + 1),
                "displayType": .string(item.displayType.mcpValue),
                "maxLines": .int(item.maxLines),
                "problem": .string(item.headline.isEmpty ? "missing" : "too_long"),
            ]
            if !item.headline.isEmpty {
                json["headline"] = .string(item.headline)
                json["fill"] = .double((item.fill * 100).rounded() / 100)
            }
            if let subhead = item.subhead { json["subhead"] = .string(subhead) }
            return .object(json)
        }
        return [
            "action": "write_captions",
            "captions": .array(items),
            "how": """
            Write the missing captions and shorten the ones too long, keeping the meaning and the brand's \
            voice; check with measure_caption, then send them all with propose_captions and this run's ID \
            as run. They're saved right away and the run checks them again.
            """,
        ]
    }
}
